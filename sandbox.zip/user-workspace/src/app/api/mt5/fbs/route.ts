import { NextRequest, NextResponse } from 'next/server';

interface FBSTradeRequest {
  action: 'get_account_info' | 'place_order' | 'close_position' | 'get_positions' | 'get_symbol_info';
  symbol?: string;
  volume?: number;
  order_type?: 'BUY' | 'SELL';
  sl?: number;
  tp?: number;
  ticket?: number;
}

interface FBSAccountInfo {
  balance: number;
  equity: number;
  margin: number;
  free_margin: number;
  profit: number;
  currency: string;
  leverage: number;
  server: string;
  name: string;
  login: string;
}

interface FBSPosition {
  ticket: number;
  symbol: string;
  type: 'BUY' | 'SELL';
  volume: number;
  price_open: number;
  price_current: number;
  profit: number;
  sl: number;
  tp: number;
  comment: string;
  time: string;
}

export async function POST(request: NextRequest) {
  try {
    const { action, symbol, volume, order_type, sl, tp, ticket }: FBSTradeRequest = await request.json();
    
    console.log(`🏦 FBS MT5 Request: ${action}`, { symbol, volume, order_type });
    
    // FBS Configuration
    const fbsConfig = {
      login: process.env.FBS_LOGIN || 'demo_login',
      password: process.env.FBS_PASSWORD || 'demo_password',
      server: process.env.FBS_SERVER || 'FBS-Demo',
      magic: parseInt(process.env.FBS_MAGIC_NUMBER || '234000'),
      deviation: parseInt(process.env.FBS_DEVIATION || '20')
    };
    
    let result;
    
    switch (action) {
      case 'get_account_info':
        result = await getFBSAccountInfo(fbsConfig);
        break;
        
      case 'place_order':
        if (!symbol || !volume || !order_type) {
          return NextResponse.json(
            { success: false, error: 'Missing required parameters for order' },
            { status: 400 }
          );
        }
        result = await placeFBSOrder(fbsConfig, { symbol, volume, order_type, sl, tp });
        break;
        
      case 'close_position':
        if (!ticket) {
          return NextResponse.json(
            { success: false, error: 'Missing ticket for close position' },
            { status: 400 }
          );
        }
        result = await closeFBSPosition(fbsConfig, ticket);
        break;
        
      case 'get_positions':
        result = await getFBSPositions(fbsConfig);
        break;
        
      case 'get_symbol_info':
        result = await getFBSSymbolInfo(fbsConfig, symbol || 'EURUSD');
        break;
        
      default:
        return NextResponse.json(
          { success: false, error: 'Invalid action' },
          { status: 400 }
        );
    }
    
    return NextResponse.json({
      success: true,
      data: result,
      broker: 'FBS',
      server: fbsConfig.server,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('🚨 FBS MT5 Error:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'FBS MT5 integration failed',
        broker: 'FBS'
      },
      { status: 500 }
    );
  }
}

async function getFBSAccountInfo(config: any): Promise<FBSAccountInfo> {
  // Mock FBS account info - replace with real MT5 Python integration
  const mockAccount: FBSAccountInfo = {
    balance: 1000.00,
    equity: 1025.50,
    margin: 25.50,
    free_margin: 1000.00,
    profit: 25.50,
    currency: 'USD',
    leverage: 1000,
    server: config.server,
    name: 'FBS Demo Account',
    login: config.login
  };
  
  console.log('📊 FBS Account Info:', mockAccount);
  return mockAccount;
}

async function placeFBSOrder(config: any, orderData: any) {
  const { symbol, volume, order_type, sl, tp } = orderData;
  
  // Mock current prices
  const prices = {
    'EURUSD': { bid: 1.0845, ask: 1.0847 },
    'GBPUSD': { bid: 1.2634, ask: 1.2636 },
    'USDJPY': { bid: 149.85, ask: 149.87 },
    'AUDUSD': { bid: 0.6523, ask: 0.6525 },
    'USDCAD': { bid: 1.3756, ask: 1.3758 }
  };
  
  const price = prices[symbol as keyof typeof prices] || prices['EURUSD'];
  const executionPrice = order_type === 'BUY' ? price.ask : price.bid;
  
  // Generate mock order result
  const orderResult = {
    success: true,
    order: Math.floor(Math.random() * 1000000) + 100000,
    deal: Math.floor(Math.random() * 1000000) + 200000,
    ticket: Math.floor(Math.random() * 1000000) + 300000,
    symbol: symbol,
    volume: volume,
    type: order_type,
    price: executionPrice,
    sl: sl || 0,
    tp: tp || 0,
    profit: 0,
    comment: 'AI Trading - FBS',
    time: new Date().toISOString(),
    spread: Math.abs(price.ask - price.bid),
    commission: 0 // FBS Standard account has no commission
  };
  
  console.log('📈 FBS Order Placed:', orderResult);
  return orderResult;
}

async function closeFBSPosition(config: any, ticket: number) {
  // Mock close position
  const closeResult = {
    success: true,
    ticket: ticket,
    deal: Math.floor(Math.random() * 1000000) + 400000,
    volume: 0.01,
    price: 1.0850,
    profit: Math.random() * 20 - 10, // Random profit between -10 and +10
    comment: 'AI Close - FBS',
    time: new Date().toISOString()
  };
  
  console.log('🔒 FBS Position Closed:', closeResult);
  return closeResult;
}

async function getFBSPositions(config: any): Promise<FBSPosition[]> {
  // Mock open positions
  const mockPositions: FBSPosition[] = [
    {
      ticket: 123456,
      symbol: 'EURUSD',
      type: 'BUY',
      volume: 0.01,
      price_open: 1.0840,
      price_current: 1.0847,
      profit: 0.70,
      sl: 1.0820,
      tp: 1.0880,
      comment: 'AI Trading - FBS',
      time: new Date(Date.now() - 3600000).toISOString() // 1 hour ago
    },
    {
      ticket: 123457,
      symbol: 'GBPUSD',
      type: 'SELL',
      volume: 0.01,
      price_open: 1.2640,
      price_current: 1.2635,
      profit: 0.50,
      sl: 1.2660,
      tp: 1.2600,
      comment: 'AI Trading - FBS',
      time: new Date(Date.now() - 1800000).toISOString() // 30 minutes ago
    }
  ];
  
  console.log('📋 FBS Open Positions:', mockPositions);
  return mockPositions;
}

async function getFBSSymbolInfo(config: any, symbol: string) {
  // Mock symbol information
  const symbolsInfo = {
    'EURUSD': {
      symbol: 'EURUSD',
      bid: 1.0845,
      ask: 1.0847,
      spread: 0.2,
      point: 0.00001,
      digits: 5,
      min_lot: 0.01,
      max_lot: 100.0,
      lot_step: 0.01,
      contract_size: 100000,
      trade_mode: 'FULL',
      margin_initial: 0.33,
      swap_long: -7.5,
      swap_short: 2.1
    },
    'GBPUSD': {
      symbol: 'GBPUSD',
      bid: 1.2634,
      ask: 1.2636,
      spread: 0.2,
      point: 0.00001,
      digits: 5,
      min_lot: 0.01,
      max_lot: 100.0,
      lot_step: 0.01,
      contract_size: 100000,
      trade_mode: 'FULL',
      margin_initial: 0.33,
      swap_long: -8.2,
      swap_short: 3.1
    }
  };
  
  const info = symbolsInfo[symbol as keyof typeof symbolsInfo] || symbolsInfo['EURUSD'];
  console.log('💱 FBS Symbol Info:', info);
  return info;
}

export async function GET() {
  return NextResponse.json({
    message: 'FBS MT5 Integration Endpoint',
    broker: 'FBS',
    description: 'Connect to FBS MetaTrader 5 for live trading',
    actions: [
      'get_account_info',
      'place_order', 
      'close_position',
      'get_positions',
      'get_symbol_info'
    ],
    demo_mode: process.env.FBS_SERVER?.includes('Demo') || true,
    supported_symbols: ['EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'USDCAD'],
    min_lot: 0.01,
    max_leverage: 3000,
    commission: 'No commission on Standard account',
    spreads: 'From 0.0 pips',
    deposit_methods: ['Card', 'Bank Transfer', 'E-wallets'],
    min_deposit: '$1 USD'
  });
}
