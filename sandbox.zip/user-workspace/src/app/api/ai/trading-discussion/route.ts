import { NextRequest, NextResponse } from 'next/server';
import { aiService } from '@/lib/aiService';

interface TradingDiscussionRequest {
  action: 'open_position' | 'close_position' | 'analyze_market';
  symbol?: string;
  type?: 'BUY' | 'SELL';
  volume?: number;
  ticket?: number;
  current_price?: number;
  market_data?: any;
  user_input?: string;
}

interface AIDiscussionResponse {
  ai1_analysis?: string;
  ai2_validation?: string;
  ai3_strategy?: string;
  ai4_sentiment?: string;
  consensus?: 'APPROVE' | 'REJECT' | 'DISCUSS_MORE';
  final_decision?: string;
  risk_assessment?: string;
  recommended_action?: string;
}

export async function POST(request: NextRequest) {
  try {
    const { action, symbol, type, volume, ticket, current_price, market_data, user_input }: TradingDiscussionRequest = await request.json();
    
    console.log(`🤖 AI Trading Discussion: ${action}`, { symbol, type, volume, ticket });
    
    let discussionResult: AIDiscussionResponse;
    
    switch (action) {
      case 'open_position':
        discussionResult = await discussOpenPosition(symbol!, type!, volume!, current_price, market_data);
        break;
        
      case 'close_position':
        discussionResult = await discussClosePosition(ticket!, symbol!, current_price);
        break;
        
      case 'analyze_market':
        discussionResult = await discussMarketAnalysis(symbol, market_data, user_input);
        break;
        
      default:
        return NextResponse.json(
          { success: false, error: 'Invalid discussion action' },
          { status: 400 }
        );
    }
    
    return NextResponse.json({
      success: true,
      discussion: discussionResult,
      timestamp: new Date().toISOString(),
      participants: ['AI 1 - Technical', 'AI 2 - Validator', 'AI 3 - Executor', 'AI 4 - Sentiment']
    });
    
  } catch (error) {
    console.error('🚨 AI Trading Discussion Error:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'AI discussion failed'
      },
      { status: 500 }
    );
  }
}

async function discussOpenPosition(symbol: string, type: 'BUY' | 'SELL', volume: number, current_price?: number, market_data?: any): Promise<AIDiscussionResponse> {
  console.log('🔵 AI 1 - Starting technical analysis...');
  
  // AI 1 - Technical Analysis
  const ai1Response = await aiService.chat([
    {
      role: 'system',
      content: `You are AI 1 - Technical Analysis Expert. Analyze the ${symbol} ${type} signal with volume ${volume}. 
      Consider: RSI, MACD, Moving Averages, Bollinger Bands, Support/Resistance levels.
      Provide clear technical reasoning for or against this trade.`
    },
    {
      role: 'user',
      content: `Should we open ${type} position on ${symbol} with volume ${volume}? Current price: ${current_price || 'Market price'}`
    }
  ]);
  
  console.log('🟡 AI 2 - Validating signal...');
  
  // AI 2 - Signal Validation
  const ai2Response = await aiService.chat([
    {
      role: 'system',
      content: `You are AI 2 - Signal Validator. Review AI 1's analysis and cross-validate the trading signal.
      Challenge the analysis if needed. Only approve high-probability trades.`
    },
    {
      role: 'user',
      content: `AI 1 Analysis: ${ai1Response.data}
      
      Please validate this ${type} signal for ${symbol}. Do you agree or disagree? Why?`
    }
  ]);
  
  console.log('🔴 AI 3 - Strategy planning...');
  
  // AI 3 - Strategy & Risk Management
  const ai3Response = await aiService.chat([
    {
      role: 'system',
      content: `You are AI 3 - Strategy Executor. Based on AI 1 and AI 2 analysis, determine:
      - Stop Loss level
      - Take Profit level  
      - Position size appropriateness
      - Risk/Reward ratio
      - Entry timing`
    },
    {
      role: 'user',
      content: `AI 1: ${ai1Response.data}
      AI 2: ${ai2Response.data}
      
      Plan the execution strategy for ${type} ${symbol} volume ${volume}. Include SL, TP, and risk assessment.`
    }
  ]);
  
  console.log('🟢 AI 4 - Sentiment analysis...');
  
  // AI 4 - Market Sentiment & News
  const ai4Response = await aiService.chat([
    {
      role: 'system',
      content: `You are AI 4 - Market Sentiment Analyst. Consider:
      - Current market sentiment
      - Economic news impact
      - Fundamental factors
      - Overall market conditions`
    },
    {
      role: 'user',
      content: `Considering current market sentiment and news, what's your view on opening ${type} position for ${symbol}?
      
      Technical Analysis: ${ai1Response.data}
      Validation: ${ai2Response.data}
      Strategy: ${ai3Response.data}`
    }
  ]);
  
  // Determine consensus
  const consensus = determineConsensus([ai1Response.data!, ai2Response.data!, ai3Response.data!, ai4Response.data!]);
  
  return {
    ai1_analysis: ai1Response.data,
    ai2_validation: ai2Response.data,
    ai3_strategy: ai3Response.data,
    ai4_sentiment: ai4Response.data,
    consensus: consensus.decision,
    final_decision: consensus.reasoning,
    risk_assessment: extractRiskAssessment(ai3Response.data!),
    recommended_action: consensus.action
  };
}

async function discussClosePosition(ticket: number, symbol: string, current_price?: number): Promise<AIDiscussionResponse> {
  console.log('🔵 AI 1 - Analyzing close signal...');
  
  // AI 1 - Technical Analysis for Close
  const ai1Response = await aiService.chat([
    {
      role: 'system',
      content: `You are AI 1 - Technical Analysis Expert. Analyze whether to close position ${ticket} for ${symbol}.
      Consider current technical indicators and price action.`
    },
    {
      role: 'user',
      content: `Should we close position ${ticket} (${symbol}) at current price ${current_price || 'market price'}? 
      Analyze the technical situation.`
    }
  ]);
  
  console.log('🟡 AI 2 - Validating close decision...');
  
  // AI 2 - Close Validation
  const ai2Response = await aiService.chat([
    {
      role: 'system',
      content: `You are AI 2 - Signal Validator. Review the close decision for position ${ticket}.
      Consider profit/loss, market conditions, and risk management.`
    },
    {
      role: 'user',
      content: `AI 1 suggests: ${ai1Response.data}
      
      Do you agree with closing position ${ticket} (${symbol}) now? What are the pros and cons?`
    }
  ]);
  
  console.log('🔴 AI 3 - Exit strategy...');
  
  // AI 3 - Exit Strategy
  const ai3Response = await aiService.chat([
    {
      role: 'system',
      content: `You are AI 3 - Strategy Executor. Determine the best exit strategy for position ${ticket}.
      Consider timing, partial close options, and profit optimization.`
    },
    {
      role: 'user',
      content: `Position ${ticket} (${symbol}) close analysis:
      AI 1: ${ai1Response.data}
      AI 2: ${ai2Response.data}
      
      What's the optimal exit strategy? Close now, partial close, or hold?`
    }
  ]);
  
  console.log('🟢 AI 4 - Market impact assessment...');
  
  // AI 4 - Market Sentiment for Close
  const ai4Response = await aiService.chat([
    {
      role: 'system',
      content: `You are AI 4 - Market Sentiment Analyst. Assess market conditions for closing position ${ticket}.
      Consider news events, market volatility, and timing factors.`
    },
    {
      role: 'user',
      content: `Should we close ${symbol} position ${ticket} considering current market sentiment and upcoming events?
      
      Technical: ${ai1Response.data}
      Validation: ${ai2Response.data}
      Strategy: ${ai3Response.data}`
    }
  ]);
  
  // Determine consensus for close
  const consensus = determineConsensus([ai1Response.data!, ai2Response.data!, ai3Response.data!, ai4Response.data!], 'close');
  
  return {
    ai1_analysis: ai1Response.data,
    ai2_validation: ai2Response.data,
    ai3_strategy: ai3Response.data,
    ai4_sentiment: ai4Response.data,
    consensus: consensus.decision,
    final_decision: consensus.reasoning,
    risk_assessment: extractRiskAssessment(ai3Response.data!),
    recommended_action: consensus.action
  };
}

async function discussMarketAnalysis(symbol?: string, market_data?: any, user_input?: string): Promise<AIDiscussionResponse> {
  const analysisSymbol = symbol || 'EURUSD';
  
  // General market discussion between all AIs
  const ai1Response = await aiService.chat([
    {
      role: 'system',
      content: 'You are AI 1 - Technical Analysis Expert. Provide current market analysis and technical outlook.'
    },
    {
      role: 'user',
      content: user_input || `What's your technical analysis for ${analysisSymbol} and overall market conditions?`
    }
  ]);
  
  const ai2Response = await aiService.chat([
    {
      role: 'system',
      content: 'You are AI 2 - Signal Validator. Provide market validation and risk assessment perspective.'
    },
    {
      role: 'user',
      content: `${user_input || `Market analysis for ${analysisSymbol}`}. AI 1 says: ${ai1Response.data}`
    }
  ]);
  
  const ai3Response = await aiService.chat([
    {
      role: 'system',
      content: 'You are AI 3 - Strategy Executor. Provide strategic market outlook and trading opportunities.'
    },
    {
      role: 'user',
      content: `Market discussion: ${user_input || `Strategic outlook for ${analysisSymbol}`}. Previous analysis: ${ai1Response.data} ${ai2Response.data}`
    }
  ]);
  
  const ai4Response = await aiService.chat([
    {
      role: 'system',
      content: 'You are AI 4 - Market Sentiment Analyst. Provide sentiment analysis and news impact assessment.'
    },
    {
      role: 'user',
      content: `${user_input || `Sentiment analysis for ${analysisSymbol} and market conditions`}. Team discussion: ${ai1Response.data} ${ai2Response.data} ${ai3Response.data}`
    }
  ]);
  
  return {
    ai1_analysis: ai1Response.data,
    ai2_validation: ai2Response.data,
    ai3_strategy: ai3Response.data,
    ai4_sentiment: ai4Response.data,
    consensus: 'DISCUSS_MORE',
    final_decision: 'Market analysis completed. Ready for further discussion or specific trading decisions.',
    recommended_action: 'Continue monitoring and discuss specific trading opportunities.'
  };
}

function determineConsensus(responses: string[], action: 'open' | 'close' = 'open'): { decision: 'APPROVE' | 'REJECT' | 'DISCUSS_MORE', reasoning: string, action: string } {
  // Simple consensus logic - in real implementation, use more sophisticated NLP
  const positiveKeywords = ['approve', 'good', 'buy', 'bullish', 'positive', 'strong', 'recommend', 'favorable'];
  const negativeKeywords = ['reject', 'bad', 'sell', 'bearish', 'negative', 'weak', 'avoid', 'risky'];
  
  let positiveCount = 0;
  let negativeCount = 0;
  
  responses.forEach(response => {
    const lowerResponse = response.toLowerCase();
    positiveKeywords.forEach(keyword => {
      if (lowerResponse.includes(keyword)) positiveCount++;
    });
    negativeKeywords.forEach(keyword => {
      if (lowerResponse.includes(keyword)) negativeCount++;
    });
  });
  
  if (positiveCount > negativeCount + 2) {
    return {
      decision: 'APPROVE',
      reasoning: `AI consensus reached: ${positiveCount} positive signals vs ${negativeCount} negative signals. Trade approved.`,
      action: action === 'open' ? 'EXECUTE_TRADE' : 'CLOSE_POSITION'
    };
  } else if (negativeCount > positiveCount + 2) {
    return {
      decision: 'REJECT',
      reasoning: `AI consensus reached: ${negativeCount} negative signals vs ${positiveCount} positive signals. Trade rejected.`,
      action: 'NO_ACTION'
    };
  } else {
    return {
      decision: 'DISCUSS_MORE',
      reasoning: `Mixed signals detected: ${positiveCount} positive vs ${negativeCount} negative. Further discussion needed.`,
      action: 'CONTINUE_ANALYSIS'
    };
  }
}

function extractRiskAssessment(strategyResponse: string): string {
  // Extract risk-related information from AI 3's response
  const riskKeywords = ['risk', 'stop loss', 'take profit', 'drawdown', 'volatility'];
  const sentences = strategyResponse.split('.');
  
  const riskSentences = sentences.filter(sentence => 
    riskKeywords.some(keyword => sentence.toLowerCase().includes(keyword))
  );
  
  return riskSentences.join('. ') || 'Risk assessment: Standard risk management applies.';
}

export async function GET() {
  return NextResponse.json({
    message: 'AI Trading Discussion Endpoint',
    description: 'Multi-AI discussion system for trading decisions',
    actions: [
      'open_position - Discuss opening new position',
      'close_position - Discuss closing existing position', 
      'analyze_market - General market analysis discussion'
    ],
    ai_participants: [
      'AI 1 - Technical Analysis Expert',
      'AI 2 - Signal Validator',
      'AI 3 - Strategy Executor', 
      'AI 4 - Market Sentiment Analyst'
    ],
    consensus_options: ['APPROVE', 'REJECT', 'DISCUSS_MORE'],
    example_request: {
      action: 'open_position',
      symbol: 'EURUSD',
      type: 'BUY',
      volume: 0.01,
      current_price: 1.0850
    }
  });
}
