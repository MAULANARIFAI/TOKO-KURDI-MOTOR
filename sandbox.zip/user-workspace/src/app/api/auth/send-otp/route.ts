import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json();

    if (!email) {
      return NextResponse.json(
        { success: false, error: 'Email wajib diisi' },
        { status: 400 }
      );
    }

    // Mock OTP generation
    const otpCode = '123456'; // Demo OTP code
    
    // In real implementation, you would:
    // 1. Generate random 6-digit OTP
    // 2. Store OTP in database with expiration
    // 3. Send email via service like SendGrid, Nodemailer, etc.
    
    console.log(`📧 DEMO OTP untuk ${email}: ${otpCode}`);
    console.log(`📱 Gunakan kode OTP: ${otpCode} untuk verifikasi`);

    // Simulate email sending delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    return NextResponse.json({
      success: true,
      message: `Kode OTP telah dikirim ke ${email}`,
      demo: {
        note: 'Ini adalah mode demo',
        otpCode: otpCode,
        instruction: 'Gunakan kode 123456 untuk verifikasi'
      }
    });

  } catch (error) {
    console.error('Send OTP error:', error);
    return NextResponse.json(
      { success: false, error: 'Gagal mengirim OTP' },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'OTP Service Endpoint',
    description: 'Mengirim kode OTP untuk verifikasi email',
    demoMode: true,
    demoOTP: '123456',
    usage: 'POST dengan { email: "user@example.com" }',
    realImplementation: {
      steps: [
        '1. Generate random 6-digit OTP',
        '2. Store OTP in database with 5-minute expiration',
        '3. Send email via SendGrid/Nodemailer',
        '4. Return success response'
      ],
      requiredServices: [
        'Email service (SendGrid, AWS SES, Nodemailer)',
        'Database for OTP storage',
        'Environment variables for email credentials'
      ]
    }
  });
}
