"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { getLocalStorage, setLocalStorage, removeLocalStorage, formatDate } from "@/lib/utils";

interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  createdAt: string;
}

export default function ProfilePage() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: ""
  });

  // Fix hydration mismatch
  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;

    const userData = getLocalStorage('user');
    const token = getLocalStorage('token');
    
    if (!userData || !token) {
      router.push('/auth/login');
      return;
    }
    
    setUser(userData);
    setFormData({
      name: userData.name || "",
      email: userData.email || "",
      phone: userData.phone || "",
      currentPassword: "",
      newPassword: "",
      confirmPassword: ""
    });
  }, [router, mounted]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);

    try {
      // Mock update - in real app, call API
      const updatedUser = {
        ...user!,
        name: formData.name,
        email: formData.email,
        phone: formData.phone
      };

      // Update localStorage
      setLocalStorage('user', updatedUser);
      setUser(updatedUser);
      
      setMessage({ type: 'success', text: 'Profil berhasil diperbarui!' });
      setIsEditing(false);
      
    } catch (error) {
      setMessage({ type: 'error', text: 'Gagal memperbarui profil' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.currentPassword || !formData.newPassword) {
      setMessage({ type: 'error', text: 'Password lama dan baru wajib diisi' });
      return;
    }
    
    if (formData.newPassword !== formData.confirmPassword) {
      setMessage({ type: 'error', text: 'Konfirmasi password tidak cocok' });
      return;
    }
    
    if (formData.newPassword.length < 6) {
      setMessage({ type: 'error', text: 'Password baru minimal 6 karakter' });
      return;
    }

    setIsLoading(true);
    
    try {
      // Mock password change
      setMessage({ type: 'success', text: 'Password berhasil diubah!' });
      setFormData(prev => ({
        ...prev,
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      }));
    } catch (error) {
      setMessage({ type: 'error', text: 'Gagal mengubah password' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    removeLocalStorage('user');
    removeLocalStorage('token');
    router.push('/auth/login');
  };

  // Show loading until mounted and user data is loaded
  if (!mounted || !user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center">
        <div className="text-white text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      {/* Header */}
      <header className="border-b border-gray-800 bg-black/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard" className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-lg">MR</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white">Maulana Rifai Trending 01</h1>
                  <p className="text-sm text-gray-400">Profil Pengguna</p>
                </div>
              </Link>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-green-400 border-green-400">
                Online
              </Badge>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="w-full lg:w-64">
            <Card className="bg-black/50 border-gray-800">
              <CardContent className="p-4">
                <nav className="space-y-2">
                  <Link href="/dashboard" className="flex items-center space-x-2 p-2 rounded-lg text-gray-300 hover:bg-gray-800 hover:text-white transition-colors">
                    <span>Dashboard</span>
                  </Link>
                  <Link href="/ai-room" className="flex items-center space-x-2 p-2 rounded-lg text-gray-300 hover:bg-gray-800 hover:text-white transition-colors">
                    <span>AI Room</span>
                  </Link>
                  <Link href="/trading-log" className="flex items-center space-x-2 p-2 rounded-lg text-gray-300 hover:bg-gray-800 hover:text-white transition-colors">
                    <span>Trading Log</span>
                  </Link>
                  <div className="flex items-center space-x-2 p-2 rounded-lg bg-gray-800 text-white">
                    <span>Profile</span>
                  </div>
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="flex-1 space-y-6">
            {message && (
              <Alert className={message.type === 'error' ? 'border-red-500 bg-red-500/10' : 'border-green-500 bg-green-500/10'}>
                <AlertDescription className={message.type === 'error' ? 'text-red-400' : 'text-green-400'}>
                  {message.text}
                </AlertDescription>
              </Alert>
            )}

            {/* Profile Information */}
            <Card className="bg-black/50 border-gray-800">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-white">Informasi Profil</CardTitle>
                    <CardDescription className="text-gray-400">
                      Kelola informasi akun dan preferensi Anda
                    </CardDescription>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => setIsEditing(!isEditing)}
                    disabled={isLoading}
                  >
                    {isEditing ? "Batal" : "Edit Profil"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleUpdateProfile} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-white">Nama Lengkap</Label>
                      <Input
                        id="name"
                        name="name"
                        type="text"
                        value={formData.name}
                        onChange={handleInputChange}
                        className="bg-gray-900 border-gray-700 text-white"
                        disabled={!isEditing || isLoading}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="email" className="text-white">Email</Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="bg-gray-900 border-gray-700 text-white"
                        disabled={!isEditing || isLoading}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="phone" className="text-white">Nomor Telepon</Label>
                      <Input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={handleInputChange}
                        className="bg-gray-900 border-gray-700 text-white"
                        disabled={!isEditing || isLoading}
                        placeholder="+6281234567890"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-white">Tanggal Bergabung</Label>
                      <div className="p-2 bg-gray-900 border border-gray-700 rounded-md text-gray-300">
                        {user.createdAt ? formatDate(user.createdAt) : 'N/A'}
                      </div>
                    </div>
                  </div>
                  
                  {isEditing && (
                    <div className="flex space-x-2">
                      <Button type="submit" disabled={isLoading}>
                        {isLoading ? "Menyimpan..." : "Simpan Perubahan"}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsEditing(false)}
                      >
                        Batal
                      </Button>
                    </div>
                  )}
                </form>
              </CardContent>
            </Card>

            {/* Change Password */}
            <Card className="bg-black/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Ubah Password</CardTitle>
                <CardDescription className="text-gray-400">
                  Pastikan akun Anda tetap aman dengan password yang kuat
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleChangePassword} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword" className="text-white">Password Lama</Label>
                      <Input
                        id="currentPassword"
                        name="currentPassword"
                        type="password"
                        value={formData.currentPassword}
                        onChange={handleInputChange}
                        className="bg-gray-900 border-gray-700 text-white"
                        disabled={isLoading}
                        placeholder="Masukkan password lama"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="newPassword" className="text-white">Password Baru</Label>
                      <Input
                        id="newPassword"
                        name="newPassword"
                        type="password"
                        value={formData.newPassword}
                        onChange={handleInputChange}
                        className="bg-gray-900 border-gray-700 text-white"
                        disabled={isLoading}
                        placeholder="Masukkan password baru"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword" className="text-white">Konfirmasi Password</Label>
                      <Input
                        id="confirmPassword"
                        name="confirmPassword"
                        type="password"
                        value={formData.confirmPassword}
                        onChange={handleInputChange}
                        className="bg-gray-900 border-gray-700 text-white"
                        disabled={isLoading}
                        placeholder="Ulangi password baru"
                      />
                    </div>
                  </div>
                  
                  <Button type="submit" disabled={isLoading}>
                    {isLoading ? "Mengubah..." : "Ubah Password"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Account Statistics */}
            <Card className="bg-black/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Statistik Akun</CardTitle>
                <CardDescription className="text-gray-400">
                  Ringkasan aktivitas trading Anda
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-gray-900/50 rounded-lg">
                    <div className="text-2xl font-bold text-green-400">78.3%</div>
                    <div className="text-sm text-gray-400">Success Rate</div>
                  </div>
                  <div className="text-center p-4 bg-gray-900/50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-400">1,247</div>
                    <div className="text-sm text-gray-400">Total Trades</div>
                  </div>
                  <div className="text-center p-4 bg-gray-900/50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-400">23</div>
                    <div className="text-sm text-gray-400">Active Signals</div>
                  </div>
                  <div className="text-center p-4 bg-gray-900/50 rounded-lg">
                    <div className="text-2xl font-bold text-yellow-400">$12,450</div>
                    <div className="text-sm text-gray-400">Total Profit</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Account Settings */}
            <Card className="bg-black/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Pengaturan Akun</CardTitle>
                <CardDescription className="text-gray-400">
                  Kelola preferensi dan keamanan akun
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-900/50 rounded-lg">
                  <div>
                    <div className="text-white font-medium">Notifikasi Email</div>
                    <div className="text-sm text-gray-400">Terima notifikasi trading via email</div>
                  </div>
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    Aktif
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gray-900/50 rounded-lg">
                  <div>
                    <div className="text-white font-medium">Two-Factor Authentication</div>
                    <div className="text-sm text-gray-400">Keamanan tambahan untuk akun Anda</div>
                  </div>
                  <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                    Belum Aktif
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gray-900/50 rounded-lg">
                  <div>
                    <div className="text-white font-medium">API Access</div>
                    <div className="text-sm text-gray-400">Akses API untuk integrasi eksternal</div>
                  </div>
                  <Badge variant="outline" className="text-green-400 border-green-400">
                    Aktif
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
