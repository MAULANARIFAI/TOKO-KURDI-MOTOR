"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface AIDiscussion {
  ai1_analysis?: string;
  ai2_validation?: string;
  ai3_strategy?: string;
  ai4_sentiment?: string;
  consensus?: 'APPROVE' | 'REJECT' | 'DISCUSS_MORE';
  final_decision?: string;
  risk_assessment?: string;
  recommended_action?: string;
}

interface AITradingDiscussionProps {
  onTradeApproved?: (tradeData: any) => void;
  onTradeRejected?: (reason: string) => void;
}

export default function AITradingDiscussion({ onTradeApproved, onTradeRejected }: AITradingDiscussionProps) {
  const [discussion, setDiscussion] = useState<AIDiscussion | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Form states
  const [tradeForm, setTradeForm] = useState({
    action: 'open_position',
    symbol: 'EURUSD',
    type: 'BUY',
    volume: 0.01,
    ticket: '',
    current_price: '',
    user_input: ''
  });

  const startDiscussion = async () => {
    setLoading(true);
    setError(null);
    setDiscussion(null);

    try {
      const requestData = {
        action: tradeForm.action,
        symbol: tradeForm.symbol,
        type: tradeForm.type,
        volume: parseFloat(tradeForm.volume.toString()),
        ticket: tradeForm.ticket ? parseInt(tradeForm.ticket) : undefined,
        current_price: tradeForm.current_price ? parseFloat(tradeForm.current_price) : undefined,
        user_input: tradeForm.user_input || undefined
      };

      console.log('🤖 Starting AI Discussion:', requestData);

      const response = await fetch('/api/ai/trading-discussion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData)
      });

      const data = await response.json();

      if (data.success) {
        setDiscussion(data.discussion);
        
        // Handle consensus decision
        if (data.discussion.consensus === 'APPROVE') {
          onTradeApproved?.(requestData);
        } else if (data.discussion.consensus === 'REJECT') {
          onTradeRejected?.(data.discussion.final_decision);
        }
      } else {
        throw new Error(data.error || 'Discussion failed');
      }
    } catch (error) {
      console.error('AI Discussion Error:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: string, value: any) => {
    setTradeForm(prev => ({ ...prev, [field]: value }));
  };

  const getConsensusColor = (consensus?: string) => {
    switch (consensus) {
      case 'APPROVE': return 'text-green-400 border-green-400';
      case 'REJECT': return 'text-red-400 border-red-400';
      case 'DISCUSS_MORE': return 'text-yellow-400 border-yellow-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  const getConsensusIcon = (consensus?: string) => {
    switch (consensus) {
      case 'APPROVE': return '✅';
      case 'REJECT': return '❌';
      case 'DISCUSS_MORE': return '🤔';
      default: return '💭';
    }
  };

  return (
    <div className="space-y-6">
      {/* Discussion Form */}
      <Card className="bg-black/50 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <span>🤖</span>
            <span>AI Trading Discussion</span>
          </CardTitle>
          <CardDescription className="text-gray-400">
            Diskusi dengan 4 AI sebelum membuka atau menutup posisi trading
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="action" className="text-white">Action</Label>
              <Select value={tradeForm.action} onValueChange={(value) => handleInputChange('action', value)}>
                <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-700">
                  <SelectItem value="open_position">Open Position</SelectItem>
                  <SelectItem value="close_position">Close Position</SelectItem>
                  <SelectItem value="analyze_market">Analyze Market</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="symbol" className="text-white">Symbol</Label>
              <Select value={tradeForm.symbol} onValueChange={(value) => handleInputChange('symbol', value)}>
                <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-900 border-gray-700">
                  <SelectItem value="EURUSD">EUR/USD</SelectItem>
                  <SelectItem value="GBPUSD">GBP/USD</SelectItem>
                  <SelectItem value="USDJPY">USD/JPY</SelectItem>
                  <SelectItem value="AUDUSD">AUD/USD</SelectItem>
                  <SelectItem value="USDCAD">USD/CAD</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {tradeForm.action === 'open_position' && (
              <div className="space-y-2">
                <Label htmlFor="type" className="text-white">Type</Label>
                <Select value={tradeForm.type} onValueChange={(value) => handleInputChange('type', value)}>
                  <SelectTrigger className="bg-gray-900 border-gray-700 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-900 border-gray-700">
                    <SelectItem value="BUY">BUY</SelectItem>
                    <SelectItem value="SELL">SELL</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {tradeForm.action === 'open_position' && (
              <div className="space-y-2">
                <Label htmlFor="volume" className="text-white">Volume</Label>
                <Input
                  id="volume"
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={tradeForm.volume}
                  onChange={(e) => handleInputChange('volume', e.target.value)}
                  className="bg-gray-900 border-gray-700 text-white"
                  placeholder="0.01"
                />
              </div>
            )}

            {tradeForm.action === 'close_position' && (
              <div className="space-y-2">
                <Label htmlFor="ticket" className="text-white">Ticket Number</Label>
                <Input
                  id="ticket"
                  type="number"
                  value={tradeForm.ticket}
                  onChange={(e) => handleInputChange('ticket', e.target.value)}
                  className="bg-gray-900 border-gray-700 text-white"
                  placeholder="123456"
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="current_price" className="text-white">Current Price (Optional)</Label>
              <Input
                id="current_price"
                type="number"
                step="0.00001"
                value={tradeForm.current_price}
                onChange={(e) => handleInputChange('current_price', e.target.value)}
                className="bg-gray-900 border-gray-700 text-white"
                placeholder="1.08500"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="user_input" className="text-white">Additional Context (Optional)</Label>
            <Input
              id="user_input"
              value={tradeForm.user_input}
              onChange={(e) => handleInputChange('user_input', e.target.value)}
              className="bg-gray-900 border-gray-700 text-white"
              placeholder="Any specific questions or context for the AI discussion..."
            />
          </div>

          <Button 
            onClick={startDiscussion} 
            disabled={loading}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 text-lg"
          >
            {loading ? "🤖 AI Sedang Berdiskusi..." : "🚀 Mulai Diskusi AI"}
          </Button>
        </CardContent>
      </Card>

      {/* Error Display */}
      {error && (
        <Alert className="border-red-500 bg-red-500/10">
          <AlertDescription className="text-red-400">
            Error: {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Discussion Results */}
      {discussion && (
        <Card className="bg-black/50 border-gray-800">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white">AI Discussion Results</CardTitle>
              <Badge variant="outline" className={getConsensusColor(discussion.consensus)}>
                {getConsensusIcon(discussion.consensus)} {discussion.consensus}
              </Badge>
            </div>
            <CardDescription className="text-gray-400">
              Hasil diskusi dari 4 AI specialist
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="consensus" className="space-y-4">
              <TabsList className="grid w-full grid-cols-5 bg-gray-900">
                <TabsTrigger value="consensus">Consensus</TabsTrigger>
                <TabsTrigger value="ai1">🔵 AI 1</TabsTrigger>
                <TabsTrigger value="ai2">🟡 AI 2</TabsTrigger>
                <TabsTrigger value="ai3">🔴 AI 3</TabsTrigger>
                <TabsTrigger value="ai4">🟢 AI 4</TabsTrigger>
              </TabsList>

              <TabsContent value="consensus" className="space-y-4">
                <div className="p-4 bg-gray-900/50 rounded-lg">
                  <h4 className="text-lg font-bold text-white mb-2">Final Decision</h4>
                  <p className="text-gray-300 mb-4">{discussion.final_decision}</p>
                  
                  <h4 className="text-lg font-bold text-white mb-2">Risk Assessment</h4>
                  <p className="text-gray-300 mb-4">{discussion.risk_assessment}</p>
                  
                  <h4 className="text-lg font-bold text-white mb-2">Recommended Action</h4>
                  <p className="text-gray-300">{discussion.recommended_action}</p>
                </div>

                {discussion.consensus === 'APPROVE' && (
                  <Alert className="border-green-500 bg-green-500/10">
                    <AlertDescription className="text-green-400">
                      ✅ AI Consensus: TRADE APPROVED - Semua AI setuju untuk melanjutkan trading
                    </AlertDescription>
                  </Alert>
                )}

                {discussion.consensus === 'REJECT' && (
                  <Alert className="border-red-500 bg-red-500/10">
                    <AlertDescription className="text-red-400">
                      ❌ AI Consensus: TRADE REJECTED - AI merekomendasikan untuk tidak melanjutkan
                    </AlertDescription>
                  </Alert>
                )}

                {discussion.consensus === 'DISCUSS_MORE' && (
                  <Alert className="border-yellow-500 bg-yellow-500/10">
                    <AlertDescription className="text-yellow-400">
                      🤔 AI Consensus: NEED MORE DISCUSSION - Sinyal campuran, perlu analisis lebih lanjut
                    </AlertDescription>
                  </Alert>
                )}
              </TabsContent>

              <TabsContent value="ai1" className="space-y-4">
                <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                  <h4 className="text-lg font-bold text-blue-400 mb-2">🔵 AI 1 - Technical Analysis</h4>
                  <p className="text-gray-300 whitespace-pre-wrap">{discussion.ai1_analysis}</p>
                </div>
              </TabsContent>

              <TabsContent value="ai2" className="space-y-4">
                <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                  <h4 className="text-lg font-bold text-yellow-400 mb-2">🟡 AI 2 - Signal Validator</h4>
                  <p className="text-gray-300 whitespace-pre-wrap">{discussion.ai2_validation}</p>
                </div>
              </TabsContent>

              <TabsContent value="ai3" className="space-y-4">
                <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg">
                  <h4 className="text-lg font-bold text-red-400 mb-2">🔴 AI 3 - Strategy Executor</h4>
                  <p className="text-gray-300 whitespace-pre-wrap">{discussion.ai3_strategy}</p>
                </div>
              </TabsContent>

              <TabsContent value="ai4" className="space-y-4">
                <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <h4 className="text-lg font-bold text-green-400 mb-2">🟢 AI 4 - Market Sentiment</h4>
                  <p className="text-gray-300 whitespace-pre-wrap">{discussion.ai4_sentiment}</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
