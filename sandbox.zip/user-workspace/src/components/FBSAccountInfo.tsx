"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { formatCurrency, formatPercentage } from "@/lib/utils";
import AITradingDiscussion from "./AITradingDiscussion";

interface FBSAccount {
  balance: number;
  equity: number;
  margin: number;
  free_margin: number;
  profit: number;
  currency: string;
  leverage: number;
  server: string;
  name: string;
  login: string;
}

interface FBSPosition {
  ticket: number;
  symbol: string;
  type: 'BUY' | 'SELL';
  volume: number;
  price_open: number;
  price_current: number;
  profit: number;
  sl: number;
  tp: number;
  comment: string;
  time: string;
}

export default function FBSAccountInfo() {
  const [accountInfo, setAccountInfo] = useState<FBSAccount | null>(null);
  const [positions, setPositions] = useState<FBSPosition[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [selectedPosition, setSelectedPosition] = useState<FBSPosition | null>(null);
  const [showDiscussion, setShowDiscussion] = useState(false);

  useEffect(() => {
    fetchFBSData();
    
    // Auto refresh every 30 seconds
    const interval = setInterval(fetchFBSData, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchFBSData = async () => {
    try {
      setError(null);
      
      // Fetch account info
      const accountResponse = await fetch('/api/mt5/fbs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get_account_info' })
      });
      
      const accountData = await accountResponse.json();
      
      if (accountData.success) {
        setAccountInfo(accountData.data);
      } else {
        throw new Error(accountData.error || 'Failed to fetch account info');
      }
      
      // Fetch positions
      const positionsResponse = await fetch('/api/mt5/fbs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get_positions' })
      });
      
      const positionsData = await positionsResponse.json();
      
      if (positionsData.success) {
        setPositions(positionsData.data);
      }
      
      setLastUpdate(new Date());
      
    } catch (error) {
      console.error('Failed to fetch FBS data:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const openDiscussion = (position: FBSPosition) => {
    setSelectedPosition(position);
    setShowDiscussion(true);
  };

  const handleTradeApproved = async (tradeData: any) => {
    if (!selectedPosition) return;
    
    try {
      const response = await fetch('/api/mt5/fbs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          action: 'close_position',
          ticket: selectedPosition.ticket
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Refresh data after closing position
        fetchFBSData();
        setShowDiscussion(false);
        setSelectedPosition(null);
      } else {
        setError(data.error || 'Failed to close position');
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to close position');
    }
  };

  const handleTradeRejected = (reason: string) => {
    setError(`AI rejected close position: ${reason}`);
    setShowDiscussion(false);
    setSelectedPosition(null);
  };

  // Legacy direct close function (for emergency use)
  const closePosition = async (ticket: number) => {
    const confirmed = window.confirm('⚠️ Bypass AI Discussion?\n\nThis will close the position immediately without AI consultation. Are you sure?');
    if (!confirmed) return;

    try {
      const response = await fetch('/api/mt5/fbs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          action: 'close_position',
          ticket: ticket
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        // Refresh data after closing position
        fetchFBSData();
      } else {
        setError(data.error || 'Failed to close position');
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to close position');
    }
  };

  if (loading) {
    return (
      <Card className="bg-black/50 border-gray-800">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="text-gray-400">Loading FBS MT5 account...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="bg-black/50 border-gray-800">
        <CardContent className="p-6">
          <Alert className="border-red-500 bg-red-500/10">
            <AlertDescription className="text-red-400">
              FBS Connection Error: {error}
            </AlertDescription>
          </Alert>
          <Button 
            onClick={fetchFBSData} 
            className="mt-4 w-full"
            variant="outline"
          >
            Retry Connection
          </Button>
        </CardContent>
      </Card>
    );
  }

  const marginLevel = accountInfo ? (accountInfo.equity / accountInfo.margin) * 100 : 0;
  const profitPercentage = accountInfo ? (accountInfo.profit / accountInfo.balance) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Account Overview */}
      <Card className="bg-black/50 border-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center space-x-2">
                <span>🏦 FBS MT5 Account</span>
              </CardTitle>
              <p className="text-sm text-gray-400 mt-1">
                {accountInfo?.name} • Server: {accountInfo?.server}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className="text-green-400 border-green-400">
                Connected
              </Badge>
              <Button 
                onClick={fetchFBSData} 
                size="sm" 
                variant="outline"
                className="text-xs"
              >
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-4 bg-gray-900/50 rounded-lg">
              <div className="text-2xl font-bold text-green-400">
                {formatCurrency(accountInfo?.balance || 0)}
              </div>
              <div className="text-sm text-gray-400">Balance</div>
            </div>
            <div className="text-center p-4 bg-gray-900/50 rounded-lg">
              <div className="text-2xl font-bold text-blue-400">
                {formatCurrency(accountInfo?.equity || 0)}
              </div>
              <div className="text-sm text-gray-400">Equity</div>
            </div>
            <div className="text-center p-4 bg-gray-900/50 rounded-lg">
              <div className="text-2xl font-bold text-purple-400">
                {formatCurrency(accountInfo?.margin || 0)}
              </div>
              <div className="text-sm text-gray-400">Margin</div>
            </div>
            <div className="text-center p-4 bg-gray-900/50 rounded-lg">
              <div className="text-2xl font-bold text-yellow-400">
                {formatCurrency(accountInfo?.free_margin || 0)}
              </div>
              <div className="text-sm text-gray-400">Free Margin</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-3 bg-gray-800/50 rounded-lg">
              <div className={`text-lg font-bold ${profitPercentage >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {formatCurrency(accountInfo?.profit || 0)}
              </div>
              <div className="text-sm text-gray-400">
                P&L ({formatPercentage(profitPercentage)})
              </div>
            </div>
            <div className="text-center p-3 bg-gray-800/50 rounded-lg">
              <div className="text-lg font-bold text-orange-400">
                1:{accountInfo?.leverage || 0}
              </div>
              <div className="text-sm text-gray-400">Leverage</div>
            </div>
            <div className="text-center p-3 bg-gray-800/50 rounded-lg">
              <div className={`text-lg font-bold ${marginLevel > 100 ? 'text-green-400' : marginLevel > 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                {marginLevel.toFixed(1)}%
              </div>
              <div className="text-sm text-gray-400">Margin Level</div>
            </div>
          </div>

          <div className="mt-4 text-xs text-gray-500 text-center">
            Last updated: {lastUpdate.toLocaleTimeString()}
          </div>
        </CardContent>
      </Card>

      {/* Open Positions */}
      <Card className="bg-black/50 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Open Positions ({positions.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {positions.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              No open positions
            </div>
          ) : (
            <div className="space-y-3">
              {positions.map((position) => (
                <div 
                  key={position.ticket} 
                  className="flex items-center justify-between p-4 bg-gray-900/50 rounded-lg"
                >
                  <div className="flex items-center space-x-4">
                    <div>
                      <div className="font-bold text-white">
                        {position.symbol}
                      </div>
                      <div className="text-sm text-gray-400">
                        Ticket: {position.ticket}
                      </div>
                    </div>
                    <Badge 
                      variant={position.type === 'BUY' ? 'default' : 'secondary'}
                      className={position.type === 'BUY' ? 'bg-green-600' : 'bg-red-600'}
                    >
                      {position.type}
                    </Badge>
                    <div className="text-sm">
                      <div className="text-gray-300">
                        Vol: {position.volume}
                      </div>
                      <div className="text-gray-400">
                        Entry: {position.price_open.toFixed(5)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <div className="text-gray-300">
                        Current: {position.price_current.toFixed(5)}
                      </div>
                      <div className={`font-bold ${position.profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {formatCurrency(position.profit)}
                      </div>
                    </div>
                    <div className="text-right text-xs text-gray-400">
                      <div>SL: {position.sl > 0 ? position.sl.toFixed(5) : 'None'}</div>
                      <div>TP: {position.tp > 0 ? position.tp.toFixed(5) : 'None'}</div>
                    </div>
                    <div className="flex flex-col space-y-2">
                      <Button
                        size="sm"
                        variant="default"
                        onClick={() => openDiscussion(position)}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        🤖 AI Discussion
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => closePosition(position.ticket)}
                        className="text-red-400 border-red-400 hover:bg-red-400/10"
                        title="Emergency close without AI consultation"
                      >
                        Force Close
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* AI Trading Discussion Dialog */}
      <Dialog open={showDiscussion} onOpenChange={setShowDiscussion}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto bg-gray-900 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">
              🤖 AI Trading Discussion - Close Position
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              {selectedPosition && (
                <>Diskusi AI untuk menutup posisi {selectedPosition.symbol} #{selectedPosition.ticket}</>
              )}
            </DialogDescription>
          </DialogHeader>
          
          {selectedPosition && (
            <div className="space-y-4">
              {/* Position Summary */}
              <Card className="bg-black/50 border-gray-800">
                <CardContent className="p-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="text-gray-400">Symbol:</span>
                      <div className="font-bold text-white">{selectedPosition.symbol}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Type:</span>
                      <div className="font-bold text-white">{selectedPosition.type}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Volume:</span>
                      <div className="font-bold text-white">{selectedPosition.volume}</div>
                    </div>
                    <div>
                      <span className="text-gray-400">Current P&L:</span>
                      <div className={`font-bold ${selectedPosition.profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {formatCurrency(selectedPosition.profit)}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* AI Discussion Component */}
              <AITradingDiscussion
                onTradeApproved={handleTradeApproved}
                onTradeRejected={handleTradeRejected}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
