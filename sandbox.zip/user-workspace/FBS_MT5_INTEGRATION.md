# 🏦 INTEGRASI FBS MT5 - Maulana Rifai Trending 01

## ✅ KONFIGURASI KHUSUS FBS

### 📊 **KEUNGGULAN FBS UNTUK AI TRADING:**
- ✅ **Deposit minimal:** $1 USD
- ✅ **Micro lots:** 0.01 (cocok untuk AI testing)
- ✅ **Spread rendah:** EUR/USD mulai 0.0 pips
- ✅ **Leverage tinggi:** 1:3000
- ✅ **MT5 support:** Full API access
- ✅ **No commission:** Untuk standard account

### 🔧 **FBS MT5 SERVER DETAILS:**
```
Server: FBS-Real, FBS-Demo
Login: [Your FBS Account Number]
Password: [Your FBS Password]
Server Address: mt5.fbs.com:443
```

## 🚀 **SETUP INTEGRASI FBS MT5**

### **1. Install MetaTrader 5 Python Library**
```bash
pip install MetaTrader5
pip install pandas numpy
```

### **2. FBS MT5 Connection Code**
```python
import MetaTrader5 as mt5
import pandas as pd
from datetime import datetime

class FBSMt5Integration:
    def __init__(self):
        self.connected = False
        self.account_info = None
    
    def connect_fbs(self, login, password, server="FBS-Real"):
        """Connect to FBS MT5"""
        if not mt5.initialize():
            print("MT5 initialization failed")
            return False
        
        # Connect to FBS server
        if not mt5.login(login, password=password, server=server):
            print(f"Failed to connect to {server}")
            print(f"Error: {mt5.last_error()}")
            return False
        
        self.connected = True
        self.account_info = mt5.account_info()
        print(f"Connected to FBS MT5: {self.account_info.name}")
        print(f"Balance: ${self.account_info.balance}")
        print(f"Equity: ${self.account_info.equity}")
        return True
    
    def get_account_info(self):
        """Get FBS account information"""
        if not self.connected:
            return None
        
        account = mt5.account_info()
        return {
            "balance": account.balance,
            "equity": account.equity,
            "margin": account.margin,
            "free_margin": account.margin_free,
            "profit": account.profit,
            "currency": account.currency,
            "leverage": account.leverage,
            "server": account.server,
            "name": account.name
        }
    
    def get_symbol_info(self, symbol="EURUSD"):
        """Get FBS symbol information"""
        symbol_info = mt5.symbol_info(symbol)
        if symbol_info is None:
            return None
        
        return {
            "symbol": symbol,
            "bid": symbol_info.bid,
            "ask": symbol_info.ask,
            "spread": symbol_info.spread,
            "point": symbol_info.point,
            "digits": symbol_info.digits,
            "trade_mode": symbol_info.trade_mode,
            "min_lot": symbol_info.volume_min,
            "max_lot": symbol_info.volume_max,
            "lot_step": symbol_info.volume_step
        }
    
    def place_order(self, symbol, order_type, volume, price=None, sl=None, tp=None, comment="AI Trading"):
        """Place order on FBS MT5"""
        if not self.connected:
            return {"success": False, "error": "Not connected to MT5"}
        
        # Get current price if not provided
        if price is None:
            tick = mt5.symbol_info_tick(symbol)
            if tick is None:
                return {"success": False, "error": f"Failed to get {symbol} price"}
            price = tick.ask if order_type == mt5.ORDER_TYPE_BUY else tick.bid
        
        # Prepare request
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": volume,
            "type": order_type,
            "price": price,
            "deviation": 20,
            "magic": 234000,
            "comment": comment,
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        # Add SL/TP if provided
        if sl is not None:
            request["sl"] = sl
        if tp is not None:
            request["tp"] = tp
        
        # Send order
        result = mt5.order_send(request)
        
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            return {
                "success": False,
                "error": f"Order failed: {result.retcode}",
                "comment": result.comment
            }
        
        return {
            "success": True,
            "order": result.order,
            "deal": result.deal,
            "volume": result.volume,
            "price": result.price,
            "comment": result.comment
        }
    
    def get_positions(self):
        """Get open positions"""
        positions = mt5.positions_get()
        if positions is None:
            return []
        
        return [{
            "ticket": pos.ticket,
            "symbol": pos.symbol,
            "type": "BUY" if pos.type == 0 else "SELL",
            "volume": pos.volume,
            "price_open": pos.price_open,
            "price_current": pos.price_current,
            "profit": pos.profit,
            "sl": pos.sl,
            "tp": pos.tp,
            "comment": pos.comment,
            "time": datetime.fromtimestamp(pos.time)
        } for pos in positions]
    
    def close_position(self, ticket):
        """Close position by ticket"""
        positions = mt5.positions_get(ticket=ticket)
        if not positions:
            return {"success": False, "error": "Position not found"}
        
        position = positions[0]
        
        # Prepare close request
        close_request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": position.symbol,
            "volume": position.volume,
            "type": mt5.ORDER_TYPE_SELL if position.type == 0 else mt5.ORDER_TYPE_BUY,
            "position": ticket,
            "price": mt5.symbol_info_tick(position.symbol).bid if position.type == 0 else mt5.symbol_info_tick(position.symbol).ask,
            "deviation": 20,
            "magic": 234000,
            "comment": "AI Close",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        result = mt5.order_send(close_request)
        
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            return {
                "success": False,
                "error": f"Close failed: {result.retcode}",
                "comment": result.comment
            }
        
        return {
            "success": True,
            "deal": result.deal,
            "volume": result.volume,
            "price": result.price
        }
    
    def disconnect(self):
        """Disconnect from MT5"""
        mt5.shutdown()
        self.connected = False
```

## 🔧 **UPDATE APLIKASI UNTUK FBS**

### **1. Update MT5 API Endpoint**
```typescript
// src/app/api/mt5/fbs/route.ts
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { action, symbol, volume, order_type, sl, tp } = await request.json();
    
    // FBS MT5 Integration
    const fbs_config = {
      login: process.env.FBS_LOGIN,
      password: process.env.FBS_PASSWORD,
      server: process.env.FBS_SERVER || "FBS-Real"
    };
    
    // Call Python MT5 script
    const result = await callFBSMt5Script(action, {
      symbol,
      volume,
      order_type,
      sl,
      tp,
      config: fbs_config
    });
    
    return NextResponse.json({
      success: true,
      data: result,
      broker: "FBS",
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('FBS MT5 Error:', error);
    return NextResponse.json(
      { success: false, error: 'FBS MT5 integration failed' },
      { status: 500 }
    );
  }
}

async function callFBSMt5Script(action: string, params: any) {
  // Implementation to call Python MT5 script
  // This would use child_process to run Python script
  // or HTTP request to Python Flask server
  
  // Mock response for now
  return {
    action: action,
    symbol: params.symbol,
    volume: params.volume,
    price: 1.0850,
    spread: 0.8,
    balance: 1000.00,
    equity: 1000.00,
    margin: 0.00,
    free_margin: 1000.00
  };
}
```

### **2. Environment Variables untuk FBS**
```env
# .env.local - FBS Configuration
FBS_LOGIN=your_fbs_account_number
FBS_PASSWORD=your_fbs_password
FBS_SERVER=FBS-Real
# FBS_SERVER=FBS-Demo (untuk testing)

# FBS API Settings
FBS_MAGIC_NUMBER=234000
FBS_DEVIATION=20
FBS_DEFAULT_VOLUME=0.01
```

### **3. Update Dashboard untuk FBS Data**
```typescript
// src/components/FBSAccountInfo.tsx
"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function FBSAccountInfo() {
  const [accountInfo, setAccountInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFBSAccountInfo();
  }, []);

  const fetchFBSAccountInfo = async () => {
    try {
      const response = await fetch('/api/mt5/fbs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get_account_info' })
      });
      
      const data = await response.json();
      if (data.success) {
        setAccountInfo(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch FBS account info:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading FBS account...</div>;

  return (
    <Card className="bg-black/50 border-gray-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-white">FBS MT5 Account</CardTitle>
          <Badge variant="outline" className="text-green-400 border-green-400">
            Connected
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">
              ${accountInfo?.balance?.toFixed(2) || '0.00'}
            </div>
            <div className="text-sm text-gray-400">Balance</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400">
              ${accountInfo?.equity?.toFixed(2) || '0.00'}
            </div>
            <div className="text-sm text-gray-400">Equity</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-400">
              ${accountInfo?.margin?.toFixed(2) || '0.00'}
            </div>
            <div className="text-sm text-gray-400">Margin</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-400">
              ${accountInfo?.free_margin?.toFixed(2) || '0.00'}
            </div>
            <div className="text-sm text-gray-400">Free Margin</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
```

## 🎯 **STRATEGI TRADING FBS DENGAN AI**

### **Recommended Settings untuk FBS:**
```
✅ Account Type: Standard (no commission)
✅ Minimum Lot: 0.01 (micro lot)
✅ Maximum Risk: 2% per trade
✅ Stop Loss: Always use (20-50 pips)
✅ Take Profit: 2:1 ratio (40-100 pips)
✅ Currency Pairs: EUR/USD, GBP/USD, USD/JPY
```

### **AI Trading Parameters:**
```
✅ Entry Confidence: >75%
✅ Maximum Positions: 3 concurrent
✅ Daily Loss Limit: 5%
✅ Profit Target: 10% monthly
✅ Trading Hours: London + NY session
```

## 🚀 **IMPLEMENTASI LANGKAH DEMI LANGKAH**

### **Step 1: Setup FBS Demo Account (5 menit)**
1. Login ke FBS Member Area
2. Create MT5 Demo Account
3. Download MT5 platform
4. Test connection

### **Step 2: Install Python MT5 (10 menit)**
```bash
pip install MetaTrader5 pandas numpy
```

### **Step 3: Update Aplikasi (30 menit)**
1. Add FBS configuration
2. Update MT5 endpoints
3. Add FBS account info component
4. Test with demo account

### **Step 4: Live Trading Setup (15 menit)**
1. Switch to FBS Real account
2. Deposit minimal ($1-25)
3. Update credentials
4. Start with micro lots

## ⚠️ **RISK MANAGEMENT FBS**

### **Untuk Modal Kecil ($1-25):**
- ✅ Lot size: 0.01 (micro)
- ✅ Risk per trade: $0.10-0.50
- ✅ Stop loss: 10-20 pips
- ✅ Maximum 1-2 positions
- ✅ Daily limit: $1-2 loss

### **Untuk Modal Sedang ($25-100):**
- ✅ Lot size: 0.01-0.05
- ✅ Risk per trade: $0.50-2.00
- ✅ Stop loss: 20-30 pips
- ✅ Maximum 2-3 positions
- ✅ Daily limit: $5-10 loss

**READY TO IMPLEMENT?** 
Saya bisa langsung update aplikasi untuk integrasi FBS MT5!
